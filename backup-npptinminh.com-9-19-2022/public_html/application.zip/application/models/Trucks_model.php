<?php
/**
 * Created by PhpStorm.
 * User: friend
 * Date: 20/1/2015
 * Time: 8:32 PM
 */

class Trucks_model extends MY_model {
    protected $table_name = 'trucks';
} 