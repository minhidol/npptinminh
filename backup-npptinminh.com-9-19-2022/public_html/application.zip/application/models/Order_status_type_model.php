<?php

Class Order_status_type_model extends MY_model{
    
    protected $table_name = 'order_status_type';
}
