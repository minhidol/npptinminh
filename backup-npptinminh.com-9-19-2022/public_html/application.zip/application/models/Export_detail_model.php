<?php

class Export_detail_model extends MY_model {
    protected $table_name = 'export_detail';
}
?>