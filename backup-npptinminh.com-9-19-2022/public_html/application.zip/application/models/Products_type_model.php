<?php

class Products_type_model extends MY_model {
    protected $CI;
    protected $table_name = 'products_type';
    
   
}