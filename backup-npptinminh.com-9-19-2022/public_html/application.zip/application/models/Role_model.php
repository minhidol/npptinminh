<?php

class Role_model extends MY_model{
    protected $table_name = 'roles';
    
}