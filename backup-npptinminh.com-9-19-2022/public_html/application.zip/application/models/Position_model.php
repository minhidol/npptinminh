<?php

class Position_model extends MY_model{
    protected $table_name = 'position';
}
