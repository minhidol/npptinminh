<?php


class Constants
{
    const COMMISSION_WHOLESALE = 1;
    const COMMISSION_RETAIL = 2;

    // Staff position
    const STAFF_SALER = 1;
}